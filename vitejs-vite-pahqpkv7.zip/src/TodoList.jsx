import React, {useState} from "react";
import './TodoList.css';

function TodoList() {

 
  
    return (
      <div>
        <h1>Lista de Tarefas</h1>
        <form>
          <input type="text" 
          placeholder='adicione uma tarefa' />
          

          <button
           className='Add' type='submit'>add
          </button>
          

        </form>
        <div className='ListaTarefas'>
          <div className='item'>
            <span>Tarefa de Exemplo</span>
            <button>deletar</button>
            </div>

            <div className='item completo'>
           <span>Tarefa de Exemplo</span>
           <button>deletar</button>
           </div> 

           <button className='deleteall'>Deletar</button>



        </div> 


      </div> 
   )

}

 export default TodoList